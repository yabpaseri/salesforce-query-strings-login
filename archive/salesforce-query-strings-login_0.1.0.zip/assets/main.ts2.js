var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var _STORAGE_KEY, _EFFECTIVE_TIME, _print;
class LoginDataAccessor {
  // 書き込み
  static async write(data) {
    await chrome.storage.local.set({ [__privateGet(this, _STORAGE_KEY)]: data });
    __privateGet(this, _print).call(this, "(#write)", JSON.stringify({ ...data, pw: "*".repeat(data.pw.length) }));
  }
  // 読み取り
  static async read(tab) {
    const data = (await chrome.storage.local.get(__privateGet(this, _STORAGE_KEY)))[__privateGet(this, _STORAGE_KEY)];
    if (data == null || data.tab !== tab) {
      __privateGet(this, _print).call(this, "(#read)", "Data not found");
      return void 0;
    }
    await chrome.storage.local.remove(__privateGet(this, _STORAGE_KEY));
    __privateGet(this, _print).call(this, "(#read)", JSON.stringify({ ...data, pw: "*".repeat(data.pw.length) }));
    return data;
  }
  // 期限チェック
  static async disposal() {
    const data = (await chrome.storage.local.get(__privateGet(this, _STORAGE_KEY)))[__privateGet(this, _STORAGE_KEY)];
    if (data == null)
      return;
    const now = Date.now();
    const expiration = now - data.time > __privateGet(this, _EFFECTIVE_TIME);
    if (expiration) {
      await chrome.storage.local.remove(__privateGet(this, _STORAGE_KEY));
      __privateGet(this, _print).call(this, "(#disposal)", "Data has been deleted due to expiration.");
    }
  }
}
_STORAGE_KEY = new WeakMap();
_EFFECTIVE_TIME = new WeakMap();
_print = new WeakMap();
__privateAdd(LoginDataAccessor, _STORAGE_KEY, "data");
__privateAdd(LoginDataAccessor, _EFFECTIVE_TIME, 3e4);
// 30000ms = 30s
__privateAdd(LoginDataAccessor, _print, console.log.bind(console, "[LoginDataAccessor]"));
const DISPOSAL_ALARM_KEY = "disposal";
const DISPOSAL_ALARM_INTERVAL = 0.5;
const SALESFORCE_URLS = ["https://*.salesforce.com/*"];
chrome.alarms.get(DISPOSAL_ALARM_KEY).then((alarm) => {
  if (!alarm) {
    chrome.alarms.create(DISPOSAL_ALARM_KEY, {
      delayInMinutes: DISPOSAL_ALARM_INTERVAL,
      periodInMinutes: DISPOSAL_ALARM_INTERVAL
    }).then(() => {
      console.log("alarm created.");
    });
  }
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === DISPOSAL_ALARM_KEY) {
    LoginDataAccessor.disposal();
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  var _a;
  console.log(`message received: ${message}`);
  if (message === "GET_DATA") {
    const tab = (_a = sender.tab) == null ? void 0 : _a.id;
    console.log(`tabId = ${tab}`);
    if (tab == null)
      return false;
    LoginDataAccessor.read(tab).then((data) => {
      sendResponse(data);
    });
    return true;
  }
  return false;
});
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const url = new URL(details.url);
    const tab = details.tabId;
    const time = details.timeStamp;
    const un = url.searchParams.get("un");
    const pw = url.searchParams.get("pw");
    if (tab < 0 || !un || !pw)
      return;
    const data = { tab, time, un, pw };
    LoginDataAccessor.write(data);
  },
  { urls: SALESFORCE_URLS }
);
