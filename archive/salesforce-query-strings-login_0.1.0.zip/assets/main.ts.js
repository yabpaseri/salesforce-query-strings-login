(function main() {
  const url = new URL(location.href);
  const un = url.searchParams.get("un");
  if (un == null)
    return;
  const useNewIdentity = document.getElementById("use_new_identity");
  if (useNewIdentity && useNewIdentity.checkVisibility()) {
    useNewIdentity.click();
  }
  const unInput = document.getElementById("username");
  const pwInput = document.getElementById("password");
  const loginButton = document.getElementById("Login");
  if (!(unInput && pwInput))
    return;
  (async () => {
    const data = await new Promise((ok) => chrome.runtime.sendMessage("GET_DATA", ok));
    if (data == null || data.un !== un)
      return;
    if (!loginButton) {
      alert(
        [
          "【Salesforce Query Strings Login からのメッセージ】",
          "ログインボタンが見つかりません。ユーザー名とパスワードの入力だけされます。"
        ].join("\n")
      );
    }
    unInput.value = data.un;
    pwInput.value = data.pw;
    loginButton == null ? void 0 : loginButton.click();
  })();
})();
