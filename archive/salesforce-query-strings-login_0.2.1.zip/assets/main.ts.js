chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  sendResponse(true);
  const EXTENSION_ORIGIN = new URL(chrome.runtime.getURL("")).origin;
  if (EXTENSION_ORIGIN !== sender.origin)
    return;
  const data = message;
  const useNewIdentity = document.getElementById("use_new_identity");
  if (useNewIdentity && useNewIdentity.checkVisibility()) {
    useNewIdentity.click();
  }
  const unInput = document.getElementById("username");
  const pwInput = document.getElementById("password");
  const loginButton = document.getElementById("Login");
  if (!(unInput && pwInput))
    return;
  unInput.value = data.un;
  pwInput.value = data.pw;
  loginButton == null ? void 0 : loginButton.click();
});
