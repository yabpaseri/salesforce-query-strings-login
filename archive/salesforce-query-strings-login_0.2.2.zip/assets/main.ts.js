const print = console.log.bind(console, "%c SALESFORCE_QUERY_STRINGS_LOGIN %c", "background-color:#92D1EA;", "");
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  sendResponse(true);
  print("Received message from service-worker.");
  const EXTENSION_ORIGIN = new URL(chrome.runtime.getURL("")).origin;
  if (EXTENSION_ORIGIN !== sender.origin)
    return;
  const data = message;
  print(`LoginData = ${JSON.stringify({ ...data, pw: "*".repeat(data.pw.length) })}`);
  const useNewIdentity = document.getElementById("use_new_identity");
  if (useNewIdentity && useNewIdentity.checkVisibility()) {
    useNewIdentity.click();
  }
  const unInput = document.getElementById("username");
  const pwInput = document.getElementById("password");
  const loginButton = document.getElementById("Login");
  if (!(unInput && pwInput))
    return;
  unInput.value = data.un;
  pwInput.value = data.pw;
  if (loginButton) {
    loginButton.click();
  } else {
    print("Login button not found.");
  }
});
