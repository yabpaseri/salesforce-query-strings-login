const SALESFORCE_URL_REGEXP_PATTERN = "^https://.+\\.salesforce\\.com/.*$";
const SALESFORCE_URLS = ["https://*.salesforce.com/*"];
const sendQueue = /* @__PURE__ */ new Map();
const requestedMap = /* @__PURE__ */ new Map();
const dataToMaskedStr = (data) => JSON.stringify({ ...data, pw: "*".repeat(data.pw.length) });
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (!(details.frameId === 0 && details.parentFrameId === -1 && details.frameType === "outermost_frame"))
    return;
  if (sendQueue.delete(details.tabId)) {
    console.log("[webNavigation.onBeforeNavigate]", `Deleted from sendQueue(${details.tabId})`);
  }
});
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.frameId !== 0 || details.parentFrameId !== -1 || details.tabId < 0)
      return;
    const url = new URL(details.url);
    const un = url.searchParams.get("un");
    const pw = url.searchParams.get("pw");
    if (!un || !pw)
      return;
    const requestId = details.requestId;
    const data = { un, pw };
    requestedMap.set(requestId, data);
    console.log("[webRequest.onBeforeRequest]", `Added to requestedMap(${requestId}): ${dataToMaskedStr(data)}`);
  },
  { urls: SALESFORCE_URLS }
);
chrome.webRequest.onCompleted.addListener(
  (details) => {
    const requestId = details.requestId;
    const data = requestedMap.get(requestId);
    if (data == null)
      return;
    sendQueue.set(details.tabId, data);
    requestedMap.delete(requestId);
    console.log("[webRequest.onCompleted]", `Move to sendQueue(${details.tabId}) from requested(${requestId}): ${dataToMaskedStr(data)}`);
  },
  { urls: SALESFORCE_URLS }
);
chrome.webNavigation.onCompleted.addListener(
  (details) => {
    if (!(details.frameId === 0 && details.frameType === "outermost_frame"))
      return;
    const tabId = details.tabId;
    const data = sendQueue.get(tabId);
    if (data != null) {
      sendQueue.delete(tabId);
      chrome.tabs.sendMessage(tabId, data, (res) => {
        if (res) {
          console.log("[webNavigation.onCompleted]", `Send data to content_script(tabId=${tabId}): ${dataToMaskedStr(data)}`);
        }
      });
    }
  },
  { url: [{ urlMatches: SALESFORCE_URL_REGEXP_PATTERN }] }
);
